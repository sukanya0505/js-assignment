let quest;
do{
    quest=prompt("Please enter a number greater than 100","<enter here>");
}while(quest<=100 && quest);
