let shoppingList=["chips","oil","vegetables","fruits","wheat"];
let shoppingBasket=["rice",...shoppingList,"Biscuit","chocolate"]
console.log(shoppingList);
console.log(shoppingBasket);