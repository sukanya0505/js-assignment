
let n =prompt("Please enter the number")
for (var counter = 0; counter <= n; counter++) {

    var notPrime = false;
    for (var i = 2; i <= counter; i++) {
        if (counter%i===0 && i!==counter) {
            
                notPrime = true;
        }
    }
    if (notPrime === false && counter!=1 && counter!=0) {
        
                console.log(`The prime number are ${counter}`);
    }
}