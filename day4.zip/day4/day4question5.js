let sales=prompt("Please enter the sales by you","<sales here>");
let commision;

if (sales>= 0 && sales<=5000){
    commision=(sales*(0.02));
}
else if (sales>= 5001 && sales<=10000){
    commision=(sales*(0.05));
}
else if (sales>= 10001 && sales<=20000){
    commision=(sales*(0.07));
}
 else if (sales>=20001){
    commision=(sales*(0.1));
}
console.log(`The total commission enered by you is ${commision}`);