let ask=(question,yes,no)=>confirm(question)?yes():no();
ask(
    'Do you agree?',
    ()=>alert("You agreed"),
    ()=>alert("You cancelled the execution")
)
/*function ask(question,yes,no){
    if(confirm(question))yes()
    else no();

}
ask(
    "do you agree",
    function(){alert("you agreed");},
    function(){alert("you cancelled");}

);*/