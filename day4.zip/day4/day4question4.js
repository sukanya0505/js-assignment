let numbers=prompt("Please enter number1,number2(only one number in case of finding squreroot)","number1 number2");
num1=Number(numbers.split(" ")[0]);
num2=Number(numbers.split(" ")[1]);
function addBy(){
    console.log(num1+num2);
}
function subtractBy(){
    console.log(num1-num2);
}
function multiplyBy(){
    console.log(num1*num2);
}
function divideBy(){
    console.log(num1/num2);
}
function sqroot(){
    console.log(Math.sqrt(num1));
}
function percent(){
    console.log((num1*0.01));
}