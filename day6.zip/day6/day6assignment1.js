var c = ["blue", "pink", "yellow", "wheat","lightblue","red"];
  var currentColor = 0;

  function changeColor() {
    document.bgColor = c[currentColor];
    currentColor = (currentColor + 1) % c.length;
    setTimeout(changeColor, 5000);
  }