var userName=prompt("Enter your name","enter your name here");
welcome.innerHTML +=` Welcome to the page ${userName}`;
function startTime() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    var s = today.getSeconds();
    m = checkTime(m);
    s = checkTime(s);
    document.getElementById('txt').innerHTML =
    h + ":" + m + ":" + s;
    var t = setTimeout(startTime, 500);
  }
  function checkTime(i) {
    if (i < 10) {i = "0" + i}; 
    return i;
  }
  function myFunction() {
    var element = document.body;
    element.classList.toggle("dark-mode");
 }