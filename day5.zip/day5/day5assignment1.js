var myarr = [];
function addTo() {
   myarr.push(document.getElementById("userinput").value);
   console.log(myarr); 
   let odd=myarr.filter(el=>el%2!=0).map(el=>el**3);
   console.log(odd);
}
