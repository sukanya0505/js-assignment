var version1=prompt("Enter the OS Name,Enter the version","os_here version_here");
osname=version1.split(" ")[0];
versionName=version1.split(" ")[1];
console.log(`The OS name is ${osname} and version is ${versionName}`);