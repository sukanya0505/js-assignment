//console.log("hello");
let input1=Number(prompt("Please enter a number to check odd or even","<number here>"));
if(input1%2 == 0){
    console.log(`The number entered is ${input1} and the number is Even`);
}
else{
    console.log(`The number entered is ${input1} and the number is Odd`);
}