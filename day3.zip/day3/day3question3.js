//console.log("hello");
let marks=Number(prompt("Please enter your marks","enter here"));

let result=(marks>=80 && marks <=100)?`Marks are ${marks} and grade is A+`:
(marks>=70 && marks <=79)?`Marks are ${marks} and grade is A`:
(marks>=60 && marks <=69)?`Marks are ${marks} and grade is B+`:
(marks>=50 && marks <=59)?`Marks are ${marks} and grade is B`:
"FAILED";
console.log(result);


if(marks>=80 && marks <=100){
    console.log(`Marks are ${marks} and grade is A+`);
}
else if(marks>=70 && marks <=79){
    console.log(`Marks are ${marks} and grade is A`);
}
else if(marks>=60 && marks <=69){
    console.log(`Marks are ${marks} and grade is B+`);
}
else if(marks>=50 && marks <=59){
    console.log(`Marks are ${marks} and grade is B`);
}
else{
    console.log("failed");
}