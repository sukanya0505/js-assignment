console.log("hellooo");
var customerName = prompt("Please enter your name", "<name goes here>");
console.log(customerName);