console.log("welcome");
let age;
age=prompt("please Enter your age: ","enter age here");
if(age>21){


console.log("Can Drink");
}
else{
    console.log("Cannot Drink");
}